<?php
/**
 * Main template file
 *
 * @package NWESTCO
 */

get_header();
?>

<main id="main-content" class="site-main" role="main">
  <div class="container">
    <?php
    if (have_posts()) :
      while (have_posts()) :
        the_post();
        ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <header class="entry-header">
            <?php
            if (is_singular()) :
              the_title('<h1 class="entry-title">', '</h1>');
            else :
              the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
            endif;
            ?>
          </header>

          <div class="entry-content">
            <?php
            if (is_singular()) :
              the_content();
            else :
              the_excerpt();
            endif;

            wp_link_pages(array(
              'before' => '<div class="page-links">' . esc_html__('Pages:', 'nwestco'),
              'after'  => '</div>',
            ));
            ?>
          </div>

          <?php if (!is_singular()) : ?>
            <footer class="entry-footer">
              <a href="<?php echo esc_url(get_permalink()); ?>" class="btn btn-primary">Read More</a>
            </footer>
          <?php endif; ?>
        </article>
        <?php
      endwhile;

      // Pagination
      the_posts_pagination(array(
        'mid_size'  => 2,
        'prev_text' => __('&laquo; Previous', 'nwestco'),
        'next_text' => __('Next &raquo;', 'nwestco'),
      ));

    else :
      ?>
      <div class="no-results">
        <h1><?php esc_html_e('Nothing Found', 'nwestco'); ?></h1>
        <p><?php esc_html_e('It seems we can\'t find what you\'re looking for.', 'nwestco'); ?></p>
        <?php get_search_form(); ?>
      </div>
      <?php
    endif;
    ?>
  </div>
</main>

<?php
get_footer();
