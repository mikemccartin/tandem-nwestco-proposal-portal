  <!-- Footer -->
  <footer class="site-footer" role="contentinfo">
    <div class="container">
      <div class="footer-content">
        <div class="footer-brand">
          <?php if (has_custom_logo()) : ?>
            <?php the_custom_logo(); ?>
          <?php else : ?>
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/nwestco_logo_flat.png" alt="<?php bloginfo('name'); ?>" class="footer-logo">
          <?php endif; ?>
        </div>

        <div class="footer-nav">
          <?php if (is_active_sidebar('footer-1') || is_active_sidebar('footer-2') || is_active_sidebar('footer-3')) : ?>
            <?php if (is_active_sidebar('footer-1')) : ?>
              <div class="footer-column">
                <?php dynamic_sidebar('footer-1'); ?>
              </div>
            <?php endif; ?>

            <?php if (is_active_sidebar('footer-2')) : ?>
              <div class="footer-column">
                <?php dynamic_sidebar('footer-2'); ?>
              </div>
            <?php endif; ?>

            <?php if (is_active_sidebar('footer-3')) : ?>
              <div class="footer-column">
                <?php dynamic_sidebar('footer-3'); ?>
              </div>
            <?php endif; ?>
          <?php else : ?>
            <!-- Default footer columns -->
            <div class="footer-column">
              <h4>Markets</h4>
              <ul>
                <li><a href="<?php echo esc_url(home_url('/markets/fuel-systems')); ?>">Fuel Systems</a></li>
                <li><a href="<?php echo esc_url(home_url('/markets/car-wash')); ?>">Car Wash</a></li>
                <li><a href="<?php echo esc_url(home_url('/markets/environmental')); ?>">Environmental</a></li>
              </ul>
            </div>

            <div class="footer-column">
              <h4>Services</h4>
              <ul>
                <li><a href="<?php echo esc_url(home_url('/services/design-engineering')); ?>">Design</a></li>
                <li><a href="<?php echo esc_url(home_url('/services/installation')); ?>">Install</a></li>
                <li><a href="<?php echo esc_url(home_url('/services/service-maintenance')); ?>">Service</a></li>
                <li><a href="<?php echo esc_url(home_url('/services/equipment-parts')); ?>">Equipment</a></li>
              </ul>
            </div>

            <div class="footer-column">
              <h4>Company</h4>
              <ul>
                <li><a href="<?php echo esc_url(home_url('/about')); ?>">About</a></li>
                <li><a href="<?php echo esc_url(home_url('/careers')); ?>">Careers</a></li>
                <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
              </ul>
            </div>

            <div class="footer-column">
              <h4>Resources</h4>
              <ul>
                <li><a href="<?php echo esc_url(home_url('/locations')); ?>">Branches</a></li>
                <li><a href="<?php echo esc_url(home_url('/projects')); ?>">Projects</a></li>
              </ul>
            </div>
          <?php endif; ?>
        </div>

        <div class="footer-contact">
          <p><strong>24/7 Emergency:</strong> <a href="tel:8007751892">800-775-1892</a></p>
          <p><strong>Email:</strong> <a href="mailto:info@nwestco.com">info@nwestco.com</a></p>
          <p>9 Branches Across 6 Western States</p>
        </div>

        <div class="footer-social">
          <a href="#" aria-label="LinkedIn">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/>
            </svg>
          </a>
          <a href="#" aria-label="Facebook">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/>
            </svg>
          </a>
          <a href="#" aria-label="YouTube">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/>
            </svg>
          </a>
        </div>
      </div>

      <div class="footer-bottom">
        <div class="footer-legal">
          <a href="<?php echo esc_url(home_url('/privacy-policy')); ?>">Privacy Policy</a>
          <span>|</span>
          <a href="<?php echo esc_url(home_url('/terms-of-service')); ?>">Terms of Service</a>
          <span>|</span>
          <a href="<?php echo esc_url(home_url('/accessibility')); ?>">Accessibility</a>
        </div>
        <p class="footer-copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. All rights reserved.</p>
      </div>
    </div>
  </footer>

  <?php wp_footer(); ?>
</body>
</html>
