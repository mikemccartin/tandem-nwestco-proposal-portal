<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

  <!-- Skip Navigation for Accessibility -->
  <a href="#main-content" class="skip-nav">Skip to main content</a>

  <!-- Header - Minimal -->
  <header class="site-header" role="banner">
    <div class="container">
      <div class="header-content">
        <div class="header-logo">
          <?php if (has_custom_logo()) : ?>
            <?php the_custom_logo(); ?>
          <?php else : ?>
            <a href="<?php echo esc_url(home_url('/')); ?>">
              <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/nwestco_logo_flat.png" alt="<?php bloginfo('name'); ?>" class="logo">
            </a>
          <?php endif; ?>
        </div>

        <div class="header-actions">
          <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary">Get Service Now</a>
          <a href="tel:8007751892" class="btn btn-outline">800-775-1892</a>
        </div>

        <button class="mobile-menu-toggle" aria-expanded="false" aria-label="Toggle navigation menu">
          <span class="hamburger"></span>
          <span class="hamburger"></span>
          <span class="hamburger"></span>
        </button>
      </div>
    </div>
  </header>

  <!-- Full-Screen Navigation Menu -->
  <nav class="fullscreen-menu" id="fullscreen-menu" aria-hidden="true">
    <div class="fullscreen-menu-content">
      <button class="menu-close" aria-label="Close navigation menu">
        <span class="sr-only">Close</span>
        <svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="8" y1="8" x2="24" y2="24"></line>
          <line x1="24" y1="8" x2="8" y2="24"></line>
        </svg>
      </button>

      <?php
      // Display custom menu structure or fallback to wp_nav_menu
      if (has_nav_menu('primary')) :
        wp_nav_menu(array(
          'theme_location' => 'primary',
          'menu_class'     => 'menu-sections',
          'container'      => 'div',
          'container_class' => 'menu-sections',
          'depth'          => 2,
          'fallback_cb'    => false
        ));
      else :
        // Fallback menu structure
      ?>
      <div class="menu-sections">
        <div class="menu-section">
          <h3>Markets</h3>
          <ul>
            <li><a href="<?php echo esc_url(home_url('/markets/fuel-systems')); ?>">Fuel Systems</a></li>
            <li><a href="<?php echo esc_url(home_url('/markets/car-wash')); ?>">Car Wash Systems</a></li>
            <li><a href="<?php echo esc_url(home_url('/markets/environmental')); ?>">Environmental Solutions</a></li>
          </ul>
        </div>

        <div class="menu-section">
          <h3>Services</h3>
          <ul>
            <li><a href="<?php echo esc_url(home_url('/services/design-engineering')); ?>">Design & Engineering</a></li>
            <li><a href="<?php echo esc_url(home_url('/services/installation')); ?>">Installation & Construction</a></li>
            <li><a href="<?php echo esc_url(home_url('/services/service-maintenance')); ?>">24/7 Service & Maintenance</a></li>
            <li><a href="<?php echo esc_url(home_url('/services/remodels-upgrades')); ?>">Remodels & Upgrades</a></li>
            <li><a href="<?php echo esc_url(home_url('/services/equipment-parts')); ?>">Equipment Sales & Parts</a></li>
            <li><a href="<?php echo esc_url(home_url('/services/testing-compliance')); ?>">Testing & Compliance</a></li>
            <li><a href="<?php echo esc_url(home_url('/services/training')); ?>">Training & Certification</a></li>
          </ul>
        </div>

        <div class="menu-section">
          <h3>Company</h3>
          <ul>
            <li><a href="<?php echo esc_url(home_url('/about')); ?>">Why Nwestco</a></li>
            <li><a href="<?php echo esc_url(home_url('/careers')); ?>">Careers</a></li>
            <li><a href="<?php echo esc_url(home_url('/contact')); ?>">Contact</a></li>
          </ul>
        </div>
      </div>
      <?php endif; ?>

      <div class="menu-cta">
        <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary btn-lg">Get Service Now</a>
        <a href="tel:8007751892" class="phone-link">24/7: 800-775-1892</a>
      </div>
    </div>
  </nav>
