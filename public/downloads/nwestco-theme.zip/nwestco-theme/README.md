# NWESTCO Custom WordPress Theme
**Version:** 1.0.0
**Author:** Tandem Theory
**Website:** https://tandemtheory.com

---

## Theme Overview

Custom WordPress theme for NWESTCO - Western US Fuel Systems, Car Wash & Environmental Solutions.

**Based on:** Option C HTML Prototype
**Features:**
- Minimal, professional design
- Full-screen navigation menu
- Responsive layout (mobile-first)
- Optimized for service-focused companies
- 24/7 emergency service call-to-actions
- SEO-ready structure
- Accessibility compliant

---

## Installation Instructions

### Method 1: Via WordPress Admin (Recommended)

1. **Log in to WordPress Admin**
   - Navigate to your WP Engine WordPress dashboard
   - Go to: `Appearance → Themes → Add New`

2. **Upload Theme**
   - Click "Upload Theme" button
   - Click "Choose File" and select `nwestco-theme.zip`
   - Click "Install Now"

3. **Activate Theme**
   - After installation completes, click "Activate"
   - Your site will now use the NWESTCO theme

### Method 2: Via SFTP

1. **Connect via SFTP**
   - Use your WP Engine SFTP credentials
   - Navigate to: `/wp-content/themes/`

2. **Upload Unzipped Theme Folder**
   - Unzip `nwestco-theme.zip` locally
   - Upload the entire `nwestco-theme/` folder via SFTP
   - Ensure folder structure is: `/wp-content/themes/nwestco-theme/`

3. **Activate in WordPress**
   - Go to: `Appearance → Themes`
   - Find "NWESTCO Custom Theme"
   - Click "Activate"

---

## What's Included

### Core Theme Files
- `style.css` - Theme metadata and main stylesheet reference
- `functions.php` - Theme functionality, asset loading, menus, widgets
- `header.php` - Site header with full-screen navigation
- `footer.php` - Site footer with contact info and menus
- `index.php` - Main template (fallback)
- `page.php` - Page template
- `screenshot.png` - Theme preview image (1200x900px)

### Assets (All from Option C Prototype)
```
assets/
├── css/
│   ├── reset.css          ← CSS reset
│   ├── variables.css      ← Color, spacing, typography variables
│   ├── base.css           ← Base styles
│   ├── buttons.css        ← Button styles
│   ├── forms.css          ← Form styles
│   ├── option-c.css       ← Main Option C styles
│   └── typography.css     ← Typography styles
├── js/
│   ├── main.js            ← Shared JavaScript
│   └── option-c.js        ← Option C specific JavaScript (navigation, etc.)
└── images/
    ├── nwestco_logo_flat.png  ← Main logo
    └── (all other images from prototype)
```

### Template Structure
```
nwestco-theme/
├── style.css
├── functions.php
├── header.php
├── footer.php
├── index.php
├── page.php
├── screenshot.png
├── README.md
├── assets/
│   ├── css/
│   ├── js/
│   ├── images/
│   └── fonts/
├── inc/               ← (Future: custom functions)
└── template-parts/    ← (Future: reusable sections)
```

---

## Post-Installation Setup

### 1. Configure Menus

**Primary Menu (Full-Screen Navigation):**
1. Go to: `Appearance → Menus`
2. Create a new menu called "Primary Menu"
3. Add pages/links in this structure:
   ```
   Markets
   ├── Fuel Systems
   ├── Car Wash Systems
   └── Environmental Solutions

   Services
   ├── Design & Engineering
   ├── Installation & Construction
   ├── 24/7 Service & Maintenance
   ├── Remodels & Upgrades
   ├── Equipment Sales & Parts
   ├── Testing & Compliance
   └── Training & Certification

   Company
   ├── Why Nwestco
   ├── Careers
   └── Contact
   ```
4. Assign to location: "Primary Menu (Full-Screen)"

**Footer Menu:**
1. Create a menu called "Footer Menu"
2. Add links to: Privacy Policy, Terms of Service, Accessibility
3. Assign to location: "Footer Menu"

### 2. Upload Custom Logo (Optional)

1. Go to: `Appearance → Customize → Site Identity`
2. Click "Select Logo"
3. Upload your logo (or use default NWESTCO logo included in theme)
4. Adjust logo size if needed

### 3. Create Essential Pages

**Recommended pages to create:**
- Home (set as front page)
- About / Why Nwestco
- Contact
- Services (parent page)
  - Design & Engineering (child)
  - Installation (child)
  - 24/7 Service & Maintenance (child)
  - etc.
- Markets (parent page)
  - Fuel Systems (child)
  - Car Wash (child)
  - Environmental (child)
- Careers
- Locations
- Privacy Policy
- Terms of Service
- Accessibility

### 4. Set Homepage

1. Go to: `Settings → Reading`
2. Select "A static page" under "Your homepage displays"
3. Choose your "Home" page from dropdown
4. Save Changes

### 5. Configure Widgets (Optional)

1. Go to: `Appearance → Widgets`
2. Add widgets to footer areas:
   - Footer Widget Area 1 (Markets menu)
   - Footer Widget Area 2 (Services menu)
   - Footer Widget Area 3 (Company menu)

---

## Theme Features

### Full-Screen Navigation
- Mobile-first hamburger menu
- Smooth slide-in animation
- Organized by sections (Markets, Services, Company)
- Prominent CTA buttons in navigation
- 24/7 emergency phone number displayed

### Header
- Minimal design with logo
- "Get Service Now" primary CTA
- Phone number (800-775-1892) secondary CTA
- Responsive mobile menu toggle

### Footer
- Multi-column footer navigation
- Contact information (phone, email)
- Social media links (LinkedIn, Facebook, YouTube)
- Legal links (Privacy, Terms, Accessibility)
- Dynamic copyright year

### Responsive Design
- Mobile-first approach
- Breakpoints optimized for all devices
- Touch-friendly buttons and navigation
- Accessible skip links

---

## Customization

### Colors
Edit: `assets/css/variables.css`
```css
:root {
  --color-primary: #D32F2F;      /* Red */
  --color-secondary: #1976D2;    /* Blue */
  --color-accent: #FFC107;       /* Yellow */
  /* etc... */
}
```

### Typography
Edit: `assets/css/variables.css`
```css
:root {
  --font-primary: 'Lato', sans-serif;
  --font-secondary: 'Open Sans', sans-serif;
}
```

### Navigation Structure
Edit: `header.php` (lines 50-93)
Or use WordPress Menus: `Appearance → Menus`

### Footer Content
Edit: `footer.php`
Or use WordPress Widgets: `Appearance → Widgets`

---

## Browser Support

- ✅ Chrome (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Edge (latest)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

---

## Technical Requirements

- **WordPress:** 6.0 or higher
- **PHP:** 7.4 or higher
- **MySQL:** 5.6 or higher

---

## WP Engine Compatibility

This theme is optimized for WP Engine hosting:
- ✅ No caching plugin needed (WP Engine has built-in caching)
- ✅ Optimized asset loading
- ✅ Follows WordPress coding standards
- ✅ Security best practices implemented

---

## Recommended Plugins

**Essential:**
- Contact Form 7 or Gravity Forms (for contact forms)
- Yoast SEO or The SEO Framework (for SEO)
- Wordfence Security (for security)

**Optional:**
- Advanced Custom Fields (ACF) Pro (for custom content fields)
- WP Rocket (for additional performance, if not using WP Engine caching)
- Smush (for image optimization)

---

## Troubleshooting

**Issue: Menu doesn't appear**
- Solution: Create menu and assign to "Primary Menu" location

**Issue: Images don't load**
- Solution: Check file paths, ensure images are in `/assets/images/` folder

**Issue: Styles look broken**
- Solution: Hard refresh browser (Cmd+Shift+R or Ctrl+Shift+R)
- Clear WP Engine cache if using WP Engine

**Issue: Full-screen menu doesn't work**
- Solution: Ensure JavaScript is enabled
- Check browser console for errors

---

## Support & Documentation

**Built by:** Tandem Theory
**Website:** https://tandemtheory.com
**Email:** hello@tandemtheory.com

**Theme Documentation:** See `WORDPRESS-THEME-CONVERSION-EXPERT-GUIDE.md`

---

## Changelog

### Version 1.0.0 (December 1, 2025)
- Initial release
- Converted from Option C HTML prototype
- Full-screen navigation menu
- Responsive design
- SEO-ready structure
- Accessibility compliant
- WP Engine optimized

---

## License

GNU General Public License v2 or later
http://www.gnu.org/licenses/gpl-2.0.html

---

**Thank you for using the NWESTCO Custom Theme!**
Built with care by Tandem Theory.
