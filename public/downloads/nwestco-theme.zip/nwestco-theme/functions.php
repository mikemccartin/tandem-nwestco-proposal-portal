<?php
/**
 * NWESTCO Theme Functions
 *
 * @package NWESTCO
 * @author Tandem Theory
 * @link https://tandemtheory.com
 */

// Prevent direct file access
if (!defined('ABPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function nwestco_theme_setup() {
    // Add theme support features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ));
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');

    // Register navigation menus
    register_nav_menus(array(
        'primary'  => esc_html__('Primary Menu (Full-Screen)', 'nwestco'),
        'footer'   => esc_html__('Footer Menu', 'nwestco'),
    ));

    // Set content width
    if (!isset($content_width)) {
        $content_width = 1200;
    }
}
add_action('after_setup_theme', 'nwestco_theme_setup');

/**
 * Enqueue Styles and Scripts
 */
function nwestco_enqueue_assets() {
    // Main theme stylesheet (contains metadata)
    wp_enqueue_style('nwestco-style', get_stylesheet_uri(), array(), '1.0.0');

    // Google Fonts
    wp_enqueue_style(
        'nwestco-fonts',
        'https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&family=Open+Sans:wght@400;600;700;800&display=swap',
        array(),
        null
    );

    // CSS Files
    wp_enqueue_style('nwestco-reset', get_template_directory_uri() . '/assets/css/reset.css', array(), '1.0.0');
    wp_enqueue_style('nwestco-variables', get_template_directory_uri() . '/assets/css/variables.css', array('nwestco-reset'), '1.0.0');
    wp_enqueue_style('nwestco-base', get_template_directory_uri() . '/assets/css/base.css', array('nwestco-variables'), '1.0.0');
    wp_enqueue_style('nwestco-buttons', get_template_directory_uri() . '/assets/css/buttons.css', array('nwestco-base'), '1.0.0');
    wp_enqueue_style('nwestco-forms', get_template_directory_uri() . '/assets/css/forms.css', array('nwestco-base'), '1.0.0');
    wp_enqueue_style('nwestco-option-c', get_template_directory_uri() . '/assets/css/option-c.css', array('nwestco-forms', 'nwestco-buttons'), '1.0.0');

    // JavaScript Files
    wp_enqueue_script('nwestco-main', get_template_directory_uri() . '/assets/js/option-c.js', array(), '1.0.0', true);

    // Pass PHP variables to JavaScript
    wp_localize_script('nwestco-main', 'nwestcoData', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('nwestco-nonce'),
    ));
}
add_action('wp_enqueue_scripts', 'nwestco_enqueue_assets');

/**
 * Register Widget Areas
 */
function nwestco_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Footer Widget Area 1', 'nwestco'),
        'id'            => 'footer-1',
        'description'   => esc_html__('Add widgets here to appear in footer column 1.', 'nwestco'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Widget Area 2', 'nwestco'),
        'id'            => 'footer-2',
        'description'   => esc_html__('Add widgets here to appear in footer column 2.', 'nwestco'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Widget Area 3', 'nwestco'),
        'id'            => 'footer-3',
        'description'   => esc_html__('Add widgets here to appear in footer column 3.', 'nwestco'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'nwestco_widgets_init');

/**
 * Custom Menu Walker for Full-Screen Menu
 */
class NWESTCO_Fullscreen_Menu_Walker extends Walker_Nav_Menu {
    // This can be customized later if needed for specific menu structure
}

/**
 * Add custom body classes
 */
function nwestco_body_classes($classes) {
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    if (!is_user_logged_in()) {
        $classes[] = 'logged-out';
    }
    return $classes;
}
add_filter('body_class', 'nwestco_body_classes');

/**
 * Excerpt Length
 */
function nwestco_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'nwestco_excerpt_length');

/**
 * Excerpt More
 */
function nwestco_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'nwestco_excerpt_more');

/**
 * Custom Image Sizes
 */
function nwestco_custom_image_sizes() {
    add_image_size('nwestco-hero', 1920, 800, true);
    add_image_size('nwestco-thumbnail', 600, 400, true);
    add_image_size('nwestco-square', 800, 800, true);
}
add_action('after_setup_theme', 'nwestco_custom_image_sizes');

/**
 * Include additional theme files
 */
// require_once get_template_directory() . '/inc/custom-post-types.php';
// require_once get_template_directory() . '/inc/custom-widgets.php';
// require_once get_template_directory() . '/inc/template-functions.php';
